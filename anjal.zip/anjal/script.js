// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAC2B4Glfqbswdtfr5ecVWJpVlH7ZToqFo",
  authDomain: "temp-31a13.firebaseapp.com",
  databaseURL: "https://temp-31a13-default-rtdb.firebaseio.com",
  projectId: "temp-31a13",
  storageBucket: "temp-31a13.firebasestorage.app",
  messagingSenderId: "990091546368",
  appId: "1:990091546368:web:de70882fa384ff50e7ede5",
  measurementId: "G-D60XZESJ7N"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const database = firebase.database();
// Send message from Profile 1
profile1Send.addEventListener('click', () => {
    if (activeProfile === 'profile1') {
        const messageText = profile1Input.value.trim();
        if (messageText !== '') {
            database.ref('messages').push({
                sender: 'profile1',
                text: messageText
            });
            profile1Input.value = ''; // Clear input field
        }
    }
});

// Send message from Profile 2
profile2Send.addEventListener('click', () => {
    if (activeProfile === 'profile2') {
        const messageText = profile2Input.value.trim();
        if (messageText !== '') {
            database.ref('messages').push({
                sender: 'profile2',
                text: messageText
            });
            profile2Input.value = ''; // Clear input field
        }
    }
});
// Listen for new messages
database.ref('messages').on('child_added', (snapshot) => {
    const message = snapshot.val();
    if (message.sender === 'profile1') {
        // Profile 1 ka message Profile 2 ke box me receive hoga
        addMessage(document.getElementById('profile2-messages'), message.text, 'received');
        if (activeProfile === 'profile1') {
            // Agar Profile 1 login hai to sent box me show hoga
            addMessage(document.getElementById('profile1-messages'), message.text, 'sent');
        }
    } else if (message.sender === 'profile2') {
        // Profile 2 ka message Profile 1 ke box me receive hoga
        addMessage(document.getElementById('profile1-messages'), message.text, 'received');
        if (activeProfile === 'profile2') {
            // Agar Profile 2 login hai to sent box me show hoga
            addMessage(document.getElementById('profile2-messages'), message.text, 'sent');
        }
    }
});
function addMessage(container, text, type) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('message', type); // 'sent' or 'received'
    messageElement.textContent = text;
    container.appendChild(messageElement);
    container.scrollTop = container.scrollHeight; // Auto-scroll to latest message
}
